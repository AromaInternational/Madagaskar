﻿CREATE USER [User_Madagaskar] FOR LOGIN [User_Madagaskar];

