﻿CREATE TABLE [dbo].[Currency_M_Tbl] (
    [CurrencyID]   INT          NOT NULL,
    [CurrencyName] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Currency_M_Tbl] PRIMARY KEY CLUSTERED ([CurrencyID] ASC)
);

